favouriteMovieGenre("cowboy")
favouriteFruit("berries")
favouriteMode("dark")
favouriteEdgeStyle("sharp")